const taskInput = document.getElementById("taskInput");
const addButton = document.getElementById("addButton");
const taskList = document.getElementById("taskList");

function addTask() {
  const task = taskInput.value.trim();

  if (task === "") {
    return;
  }

  const item = document.createElement("li");
  item.textContent = task;
  taskList.appendChild(item);

  taskInput.value = "";
  taskInput.focus();
}

addButton.addEventListener("click", addTask);

taskInput.addEventListener("keydown", (event) => {
  if (event.key === "Enter") {
    addTask();
  }
});
