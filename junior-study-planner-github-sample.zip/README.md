# Study Planner

A simple beginner web project built with HTML, CSS and JavaScript.

## Features
- Add study tasks
- Press Enter or click Add
- Dynamically displays tasks on the page
- Responsive basic layout

## Skills demonstrated
- HTML page structure
- CSS styling
- JavaScript variables and functions
- DOM manipulation
- Event listeners
- Basic input validation

## About
This is a personal learning project created to demonstrate beginner web-development skills.
